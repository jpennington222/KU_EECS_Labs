#include <iostream>
int main(int argc, char** argv)

{
	std::cout<<"This is my first lab exercise!\n";
}
