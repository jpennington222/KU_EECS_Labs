#include <iostream>
int main(int argc, char** argv)

{
	std::cout <<"My name is Joseph Pennington.\n";
	std::cout <<"I am an Interdisciplinary Computing major.\n";
	std::cout <<"\tMy hobbies are:\n";
	std::cout <<"\tClarinet\n";
	std::cout <<"\tDiving\n";
	std::cout <<"\tReading\n";
	std::cout <<"\tCollecting magnets and stickers\n";
	std::cout <<"Goodbye\n";
	return (0);

}

