Joseph Pennington & Megan Rajagopal
EECS 678 Project 1 (QUASH)

To compile the program, type "make", then enter
To run the program, type "./quash", then enter

If running executables, ensure that the command has the "./" character
