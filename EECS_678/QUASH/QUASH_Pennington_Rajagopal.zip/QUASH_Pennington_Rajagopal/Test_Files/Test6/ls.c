/* Dummy program called 'ls' to confuse 'exec' */

#include <stdio.h>

int main()
{
  printf("My Dummy program is run\n");

  return 0;
}
